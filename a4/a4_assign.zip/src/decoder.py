"""
Provided for you is the encryption alphabet used to encrypt the provided files.
This inclues: a-z, A-Z, 0-9, punctuation like .(); (not the same as in a1-a3), space and newline
"""

import string
alphabet = string.ascii_lowercase + string.ascii_uppercase + string.digits + string.punctuation + " \n"

