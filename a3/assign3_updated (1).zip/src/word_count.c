#include "word_count.h"


int 
main(int argc, char *argv[]) {

}

