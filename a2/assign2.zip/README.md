## To run all the tests:

bash run_tests.sh
./run_tests.sh

## To run on Part (A,B, or C)
python test/test_A.py
python test/test_B.py
python test/test_C.py

## understanding diff output
https://canvas.instructure.com/courses/1380806/pages/reading-unit-tests-output-diff
