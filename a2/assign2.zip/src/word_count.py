#!/bin/env python3
def main():
    pass #You can delete this one once you start coding your solution 
    #TODO


#Do not change this
if __name__ == "__main__":
    main()

    
