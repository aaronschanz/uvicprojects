#include "word_count.h" 

int
real_main(int argc, char *argv[]) {
    //TODO

    return 0;
}


#ifndef TEST
int
main(int argc, char *argv[]) {
    return real_main(argc, argv);
}
#endif
